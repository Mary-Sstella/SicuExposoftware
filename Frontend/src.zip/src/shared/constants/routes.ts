export const ROUTES = {
  LOGIN: '/login',
  DASHBOARD: '/dashboard',
  ESTUDIANTES: '/estudiantes',
  ASISTENCIA: '/asistencia',
  TURNOS: '/turnos',
  STUDENT: '/student',
  ESTADISTICAS: '/estadisticas',  
  INSCRIPCION: '/inscripcion',
  SOLICITUDES: '/solicitudes',
  STUDENT_PAGO: '/student/pago',
  CONFIGURACION: '/configuracion',
  CARTERA: '/cartera',
  BUZON: '/buzon',
  STUDENT_RESENAS: '/student/resenas',
  TURNERO: '/turnero',

}